<?php

namespace app\controllers;

class ClusterringController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

    public function actionProses($id){


        return $this->render('index');    
    }

}
