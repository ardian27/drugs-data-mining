<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\DataSeleksi */
?>
<div class="data-seleksi-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
