<?php

foreach ($data as $data){
    echo $data;
}

?>