<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\DataPreprosessing */

?>
<div class="data-preprosessing-create">
    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>
</div>
