<?php

/* @var $this yii\web\View */

$this->title = 'Drugs Mining';
?>
<div class="site-index">

    <div class="jumbotron">
        <h2>DRUGS MINING</h2>
    </div>

    <div class="body-content">

        <div class="jumbotron">
            <div class="col-lg-12 center">
            <img src="img/uin.jpg"height="100" width="100">
                <h2>Hijriah Daulay</h2>
                <h4>11351202604</h4>
                <h4>Teknik Informatika</h4>
                <h4>UIN Suska Riau</h4>                
            </div>
        </div>

    </div>
</div>
